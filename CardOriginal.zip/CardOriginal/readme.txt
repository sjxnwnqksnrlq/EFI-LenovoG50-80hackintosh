Original Apple Card Reader kext for macOS Mojave(18A377a)
